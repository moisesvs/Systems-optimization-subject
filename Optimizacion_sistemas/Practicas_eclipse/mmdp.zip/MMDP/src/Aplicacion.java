import java.io.File;


public class Aplicacion {

	public static void main(String[] args) {
		String carpeta = "instancias/GKD-Ia";
		cargarInstancias(carpeta);
		
	}

	private static void cargarInstancias(String carpeta) {
		File dir = new File(carpeta);
		File[] instancias = dir.listFiles();
		for(int i = 0; i < instancias.length; i++) {
			MMDPInstancia instancia = new MMDPInstancia(instancias[i]);
			instancia.cargar();
			instancia.imprimir();
		}
	}

}
