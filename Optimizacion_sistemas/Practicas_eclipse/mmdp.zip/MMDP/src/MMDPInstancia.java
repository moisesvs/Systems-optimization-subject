import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;


public class MMDPInstancia {

	private File fichero;
	private int n;
	private int m;
	private double[][] matrizDistancias;

	public MMDPInstancia(File fichero) {
		this.fichero = fichero;
	}

	public void cargar() {
		try {
			BufferedReader br = new BufferedReader(new FileReader(fichero));
			String line = br.readLine();
			StringTokenizer st = new StringTokenizer(line);
			n = Integer.parseInt(st.nextToken());
			m = Integer.parseInt(st.nextToken());
			
			matrizDistancias = new double[n][n];
			
			line = br.readLine();
			while(line != null) {
				st = new StringTokenizer(line);
				int x = Integer.parseInt(st.nextToken());
				int y = Integer.parseInt(st.nextToken());
				double d = Double.parseDouble(st.nextToken());
				matrizDistancias[x][y] = d;
				matrizDistancias[y][x] = d;
				line = br.readLine();
			}
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void imprimir() {
		System.out.println(fichero.getName());
		System.out.println(n + " " + m);
		for(int i = 0; i < matrizDistancias.length - 1; i++) {
			for(int j = i + 1; j < matrizDistancias.length; j++) {
				System.out.println(i + " " + j + " " + matrizDistancias[i][j]);
			}
		}
	}
	
	
}
